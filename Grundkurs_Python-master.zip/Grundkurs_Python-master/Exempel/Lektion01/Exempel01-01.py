# Ett exempel på hur print() fungerar.
print("Hello World")

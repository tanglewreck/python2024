print("HEJ")

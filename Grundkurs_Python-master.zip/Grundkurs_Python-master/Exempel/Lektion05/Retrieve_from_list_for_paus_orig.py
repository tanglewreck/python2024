# Hämta det sista elementet ut listan och skriv ut det.
# Antingen genom att kolla hur lång listan är eller genom att gå baklänges.
# Ni behöver inte använda den förberedda print-funktionen, bara det skrivs ut
# på något sätt.

list_with_funny_name = ["En", "lista", "kan", "innehålla", "olika", "saker"]

length_of_list = "Här kan ni skriva en längdräknare"

print()

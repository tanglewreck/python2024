# Demonstration av slicing på listor och strängmanipulering.
# Avancerat, endast om tid finns.

my_details = ["Johan", "Marmén", "34", "180"]

print(my_details)
print(my_details[:2])
print(" ".join(my_details[:2]))
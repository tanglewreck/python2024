my_fruits_list = ["päron", "äpplen", "apelsiner", "citroner", "vindruvor"]

print(my_fruits_list[0:3])
print(my_fruits_list[:3])

print(my_fruits_list[1:4])

print(my_fruits_list[2:5])
print(my_fruits_list[2:])
print(my_fruits_list[-3:])

print("1234567890"[0:5])

my_details = ["Johan", "Marmén", "32", "Farsta"]

print(my_details)
print(my_details[:2])
print(" ".join(my_details[:2]))

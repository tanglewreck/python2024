# Exempel som visar hur While-loopar fungerar och kan användas.

my_int = 1
my_second_int = 10

while my_int < my_second_int:
    print(my_int)
    my_int = my_int + 1

print("Nu är loopen över!")

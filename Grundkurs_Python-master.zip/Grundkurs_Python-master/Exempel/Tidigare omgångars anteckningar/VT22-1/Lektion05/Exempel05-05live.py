my_int_list = [1, 2, 3, 4, 5, 6, 7, 8, 9]

for element in my_int_list:
    print(element)

print()

index = 0
while index < len(my_int_list):
    element = my_int_list[index]
    index += 1
    print(element)

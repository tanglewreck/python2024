# Exempel på hur man kan importera funktioner från andra moduler
# och hur man referar till dem i koden.


import tobeimported

tobeimported.my_function()

# Skriv ett program som består av två moduler, varav modulen ett importerar
# den andra och kör en funktion från den andra modulen med ett argument.

# Filen med funktionen är också en del av uppgiften och funktionens
# funktion är valfri.
# Ett möjligt alternativ är en funktion som hälsar användaren
# med ett namn som anges via ett argument


# För extra utmaning kan du importera specifikt den funktion
# som du ska anropa.

# Kom ihåg att namn på moduler som ska importeras inte bör innehålla tecken
# utöver a-z och 0-9.

# Här ska du skriva namnet på din andra fil och eventuellt något mer.
import

# Så här kan det se ut när du kallar på funktionen.
my_example_function("Bob")

def add(int1, int2):
    print(int1 + int2)

add(3, 2)

def subtract(int1, int2):
    print(int1 - int2)

subtract(3, 2)

def multiply(int1, int2):
    print(int1 * int2)

multiply(3, 2)

def divide(int1, int2):
    print(int1 / int2)

divide(3, 2)

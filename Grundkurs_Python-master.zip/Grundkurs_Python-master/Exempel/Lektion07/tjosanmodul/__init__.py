def tjosan():
    print("Tjosan indeed!")
    return 42

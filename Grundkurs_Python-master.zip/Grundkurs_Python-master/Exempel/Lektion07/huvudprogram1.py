print("Här börjar programmet och dess modulnamn är:", __name__)

import tjosanmodul.extragrejer

tjosanmodul.extragrejer.mitt_namn()

print("Klart!")

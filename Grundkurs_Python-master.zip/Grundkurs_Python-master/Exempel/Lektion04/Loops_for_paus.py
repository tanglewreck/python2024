# Skriv så många av dessa loopar, eller någon egen idé, som du vill, kan och hinner:

# Exempel på möjliga loopar:


# -Skriv en loop som skriver ut alla element i en lista.

# -Skriv en loop som adderar alla int:ar från en lista och skriver ut resultatet:
# Exempellista:
my_int_list = [1, 2, 3, 4, 5, 6, 7, 8, 9]  # Summan av dessa blir 45

# Skriv en loop som frågar användaren vad hen heter och hälsar med namn tills man
# skriver något specifikt. Då ska loopen avslutas.
# Tips: Här passar en While väldigt bra.

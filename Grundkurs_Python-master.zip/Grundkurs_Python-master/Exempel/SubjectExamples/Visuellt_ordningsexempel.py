# Visuellt exempel på varför det är viktigt att tänka på vilken ordning man
# skriver saker när man programmerar.

print("    /|")
print("   / |")
print("  /  |")
print(" /   |")
print("/____|")

# Simpla datatyper
my_int = 12
my_str = "12"
my_float = 12.0
my_bool = True

# Samlingsdatatyper
my_list = [12, 13, 14]
my_tuple = (12, 13, 14)
my_dict = {12:"Twelve", 13:"Thirteen", 14:"Fourteen"}
my_set = {12, 13, 14}

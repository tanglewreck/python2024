# Exempel av input

user_name = input("Hej, vad heter du? \n Mitt namn är: ")

print("Trevligt att träffas, " + user_name + ".")

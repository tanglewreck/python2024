# Exempel av att cast:a input

tal1 = int(input("Vilket tal ska vi dubbla? "))
print(tal1 * 2)

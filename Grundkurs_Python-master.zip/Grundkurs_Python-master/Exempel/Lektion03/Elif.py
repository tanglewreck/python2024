siffra = 3

if siffra == 1:
    resultat = 1
    print("Hej")
    print("Hej")
    print("Hej")
    print("Hej")
    print("Hej")
elif siffra == 2:
    resultat = 2
elif siffra == 3:
    resultat = 3
elif siffra == 4:
    resultat = 4
elif siffra == 5:
    resultat = 5
else:    
    print("Hej")
    print("Hej")
    print("Hej")
    print("Hej")
    print("Hej")

print(resultat)

# if siffra <= 1:
#     resultat = 1
# elif siffra <= 2:
#     resultat = 2
# elif siffra <= 3:
#     resultat = 3
# elif siffra <= 4:
#     resultat = 4
# elif siffra <= 5:
#     resultat = 5
# elif siffra <= 6:
#     resultat = 6
# else:
#     resultat = "Något annat"

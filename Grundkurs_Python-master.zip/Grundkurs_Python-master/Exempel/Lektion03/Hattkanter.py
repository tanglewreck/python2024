hattkanter = 3

if hattkanter == 3:
    hatt = "min"
else:
    hatt = "inte_min"

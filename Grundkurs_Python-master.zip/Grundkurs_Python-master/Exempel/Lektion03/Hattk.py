hattk = 3

if hattk ==3:









 hatt="m"
else:
                    hatt="im"

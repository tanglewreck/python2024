siffra = -4


if siffra >= 0:
    resultat = 1
elif siffra >= 1:
    resultat = 2
elif siffra >= 2:
    resultat = 3



print(resultat)

name = input("Vad heter du? ")
age = int(input("Hur gammal är du? "))
print("Hej", name, ", jag ser att du är", age, "år.")
print(type(age))

print("Hej ", name, ", jag ser att du är ", age, " år.", sep='')
print("Hej ", name, ", jag ser att du är ", age, " år.", sep='')
print("Hej ", name, ", jag ser att du är ", age, " år.", sep='', end="\n")
print("Hej ", name, ", jag ser att du är ", age, " år.", sep='', end="\n")

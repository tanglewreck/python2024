# Här skriver vi två olika matematiska funktioner.
# I ordning så gör de addition respektive multiplikation
# av två argument som man anger när man kör funktionen.

# Uppgiften är att utöka den här filen så att den hanterar fler räknesätt
# eller operatorer.
# Lägg till minst två nya funktioner, helst några fler. Max fem nya.
# Om du inte vet vad du ska välja för räknesätt så är förslagen
# subtraktion (d.v.s. minus) och division (d.v.s. delat med).

# Länk till exempel på operatorer ( Endast de som är markerade med fet stil
# är relevanta för grundkursen:
# https://misaab-my.sharepoint.com/:w:/g/personal/johan_marmen_misa_se/ESehIlchRdpFoetFBbWIeSwBx3dZnTMy0XUxAA9_GJLpxA?e=2eE3tf


# Lägg även till anrop på dina nya funktioner så som jag gör längst ned i denna fil.


def add(int1, int2):
    print(int1 + int2)


def multiply(int1, int2):
    print(int1 * int2)


add(3, 2)
multiply(3, 2)

# Rätta till koden så att vi:
# 1. Skapar en funktion som skriver ut vad användaren skriver in.
# 2. Kör den skapade funktionen.

my_func:
    user_input = input("Vad vill du att jag ska säga? ")
    print("Jag blev ombedd att säga: ", user_input)

my_func
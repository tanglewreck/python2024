# Några fel i dessa kodrader gör att programmet inte fungerar, rätta felen:
# Ni ska inte lägga till fler rader, raderna 9 och 11 är de enda som ska ändras
# på.

print(24)

print("Hello World", "Hi")

print24 + 24

print 24 +24

print(24 + 24)

# Det här programmet kraschar för Python förstår inte vad två av raderna betyder.
# Rätta till programmet genom att använda kommentarer.
# Just här vill vi ha en mening uppdelad på flera rader, så att lägga
# all text på en rad är alltså inte rätt svar på denna övning.

# Raden med print("Vi testar om detta program kraschar.") ska inte ändras,
# den är enbart för att kontrollera att programmet körs.

# Jag vill skriva
en kommentar
på flera rader.
print("Vi testar om detta program kraschar.")

# Här vill vi hämta ut ett värde från en dict och skriva ut det.
# Komplettera koden så att den fungerar. Endast en rad ska ändra på.
# Att hårdkoda är inte rätt svar. D.v.s. det är inte rätt att ändra i print()
# så att det står "Två på engelska är: two"


my_dict = {"ett": "one", "två": "two", "tre": "three"}

print("Två på engelska är: ")
print("Raden ovanför ska vara 'Två på engelska är: two' när programmet körs.")

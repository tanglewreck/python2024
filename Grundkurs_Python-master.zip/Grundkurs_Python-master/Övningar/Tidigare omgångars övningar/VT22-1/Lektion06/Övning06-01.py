# Rätta till koden så att vi skapar en funktion som skriver ut
# vad användaren skriver in och sen kör den.

my_func:
    user_input = input("Vad vill du att jag ska säga? ")
    print("Jag blev ombedd att säga: ", user_input)

my_func
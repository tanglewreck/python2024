# Här vill vi hämta ut ett värde från en dict och skriva ut det.
# Kompletera koden så att den fungerar.


my_dict = {"ett": "one", "två": "two", "tre": "three"}

print("Två på engelska är: ")
print("Raden ska vara 'Två på englska är: two'")

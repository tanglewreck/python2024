# Lägg till parenteser så att min_variabel får värdet 12 och min_andra_variabel får värdet 16.0.

min_variabel = 2 + 4 * 2
print("min_variabel har värdet:", min_variabel)

min_andra_variabel = 20 + 40 / 10 + 10
print("min_andra_variabel har värdet:", min_andra_variabel)

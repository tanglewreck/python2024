# Komplettera koden så att "Hello World" bara skrivs ut om 20 är mindre än 30.

my_variable =
my_second_variable =
if
print("Hello World")
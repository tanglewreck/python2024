# Det här programmet kraschar för Python förstår inte vad två av raderna betyder.
# Rätta till programmet genom att använda kommentarer.
# Just här vill vi ha en mening uppdelad på flera rader, så att lägga
# all text på en rad är alltså inte rätt svar på denna övning.

# Raden med print("Kraschar detta program?") ska inte ändras, den är enbart
# för att kontrollera att programmet körs.

# Jag vill skriva
en kommentar
på flera rader.
print("Kraschar detta program?")

# Några fel i dessa kodrader gör att programmet inte fungerar, rätta felen:

print(24)

print("Hello World", "Hi")

print24 + 24

print 24 +24

print(24 + 24)

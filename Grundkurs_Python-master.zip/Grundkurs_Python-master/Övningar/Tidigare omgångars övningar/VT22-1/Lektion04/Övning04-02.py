# Returnera element från listan från det femte till det sextonde, räknat från noll.

my_long_list = ["Det", "här", "är", "en", "lista", "som", "innehåller", "väldigt",
                "många", "element", "för", "att", "visa", "att", "man", "kan", "ha",
                "radbyten", "i", "en", "deklaration"]

print("Resultatet av nästa print() ska det vara: ['som', 'innehåller', 'väldigt', 'många',"
      " 'element', 'för', 'att', 'visa', 'att', 'man', 'kan']")
print()

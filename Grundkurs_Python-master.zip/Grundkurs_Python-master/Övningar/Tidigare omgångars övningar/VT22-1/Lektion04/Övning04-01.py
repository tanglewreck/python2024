# Vänd på listan med hjälp av en metod.

en_lista = ["Det", "här", "är", "en", "lista."]

print("Här ska det stå ['lista.', 'en', 'är', 'här', 'Det']:", en_lista)

# Kompletera koden så att summan av 5 + 10 skrivs ut med hjälp av variabler

=
y = 10
print()
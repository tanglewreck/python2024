# Rätta till While-loopen så att den fungerar och skriver ut 27, 34, 41, etc. :

my_first_int = 20
my_second_int = 300

while my_first_int < my_second_int
my_first_int = my_first_int + 7
print(my_first_int)


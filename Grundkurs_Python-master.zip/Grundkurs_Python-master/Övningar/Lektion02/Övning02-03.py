# Komplettera koden så att summan av 5 + 10 skrivs ut med hjälp av variabler.
# Det behövs inte fler rader kod än de som redan är förberedda nedan.
#
# Svaret som ska skrivas ut är alltså 15 men att skriva print(15) eller
# print("15") är inte rätt svar.

=
y = 10
print()
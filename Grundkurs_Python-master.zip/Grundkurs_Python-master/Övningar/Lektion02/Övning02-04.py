a = 52
x = 48

# Raderna här under får programmet att krascha, rätta till dem så att de gör
# rätt sak (vi vill få ut tre rader; en med 52, en med 48 och en med 100).
print(A)
print(X)
print(A+X)
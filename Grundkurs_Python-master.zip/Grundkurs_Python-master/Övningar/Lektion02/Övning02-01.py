# Något i denna kodrad gör att programmet inte fungerar, rätta felet så att vi får resultatet
# Hello World1234
# Att ändra till print("Hello World1234") är inte rätt svar.

print("Hello World" + 1234)

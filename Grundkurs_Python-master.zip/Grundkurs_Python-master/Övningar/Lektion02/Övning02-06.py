# Koden nedan tar bort en etta ur samlingen, rätta till koden så att
# programmet skriver ut [1, 2, 1] när det körs.
# Notera: Raden med print ska INTE ändras.


# Förklara i en kommentar på nästa rad varför dubbletten togs bort:
#

my_list = {1, 2, 1}
print(my_list)
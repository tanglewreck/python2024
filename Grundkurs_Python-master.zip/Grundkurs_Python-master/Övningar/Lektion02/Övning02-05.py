# Detta program kraschar. Rätta till koden så att den fungerar och att vi
# får ut rätt resultat från programmet när det körs.

# Notera: Du ska alltså INTE ändra på raderna med "print" för att få ut rätt
# resultat. Raderna med text är till för att visa om du har gjort rätt.

my_list = 2, 3, 4
my_second_list = [5, 6, 7, 8]
new_list = my_list + my_second_list


# Nedanstående rader ska INTE ändras spå


print("På nästa rad ska det stå <class 'list'> när programmet körs:")
print(type(new_list))
print("På nästa rad ska det stå [2, 3, 4, 5, 6, 7, 8] när programmet körs:")
print(new_list)

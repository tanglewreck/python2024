# Några fel i dessa kodrader gör att programmet inte fungerar, rätta felen
# så att vi får resultaten 110 och 5555 när programmet körs:

my_variable = 55
my_second_variable = "55"

print(my_variable + my_second_variable)

my_third_variable = 55
my_fourth_variable = "55"

print(my_third_variable + my_fourth_variable)

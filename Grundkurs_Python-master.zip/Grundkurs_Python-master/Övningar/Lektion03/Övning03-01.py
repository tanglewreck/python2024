# Ändra i de båda print() så att vi får rätt resultat.
# Raderna där vi skapar variablerna ska alltså inte ändras och inga nya rader
# ska läggas till.
# Eftersom vi här vill använda oss av samma variabler på olika sätt
# så måste vi använda oss av det som vi gick igenom på lektion2 om att
# hämta värden som om de vore något annat.

my_first_number = 2
my_second_number = 3
my_third_number = "4"

print("Här ska det stå 9:", my_first_number + my_second_number + my_third_number)
print("Här ska det stå 234:", my_first_number + my_second_number + my_third_number)

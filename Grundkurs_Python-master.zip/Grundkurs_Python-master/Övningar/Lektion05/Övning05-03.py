# Returnera element från listan från det femte till det sextonde, räknat från noll.
# Hur ni hämtar elementen får ni välja själva men att skriva in dem manuellt
# i print() är INTE rätt svar.

my_long_list = ["Det", "här", "är", "en", "lista", "som", "innehåller", "väldigt",
                "många", "element", "för", "att", "visa", "att", "man", "kan", "ha",
                "radbyten", "i", "en", "deklaration"]
# Ovanstående rader ska INTE ändras.

print("Resultatet av nästa print() ska vara: ['som', 'innehåller', 'väldigt', 'många',"
      " 'element', 'för', 'att', 'visa', 'att', 'man', 'kan']")
print()

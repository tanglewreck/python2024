# Ändra koden nedan så att bara det element som innehåller "är" skrivs ut.
# Skapandet av listan ska INTE ändras på och att skriva in "är"
# manuellt i print() är inte rätt.

en_lista = ["Det", "här", "är", "en", "lista."]
# Ovanstående rad ska INTE ändras på


print('Här ska det stå "är" utan citattecken:', en_lista)
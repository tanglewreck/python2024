def bark():
    print("Woof!")


def bark_loudly():
    print("WOOF!!")

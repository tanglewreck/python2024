# Övning 07-02: Skapa en modul med funktioner för kattläten
# och lägg till anrop på den nya modulens funktioner i den här
# modulens main-funktion.

from exempelpaket import *


def main():
    bark()
    bark_loudly()


main()

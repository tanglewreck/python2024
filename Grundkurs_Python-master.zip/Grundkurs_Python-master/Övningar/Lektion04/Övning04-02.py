# Rätta till programmet så att när det körs får vi ut:
# 1
# 2
# 3
# 4
# 5
# 6
# 7
# Åtta
# Nio
# 10
my_list = [1, 2, 3, 4, 5, 6, 7, "Åtta", "Nio", 10]
# Ovanstående kod ska INTE ändras.


# Svara i en kommentar på nästa rad vad för typ av loop passar bäst här:


loop my_list:
    print()



# Extrafråga: Hur skulle vi kunna göra så att programmet skriver ut innehållet
# i listan på en rad istället för på flera stycken? Svara i en kommentar: